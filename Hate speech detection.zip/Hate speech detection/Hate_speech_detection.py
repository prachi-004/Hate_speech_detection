#!/usr/bin/env python
# coding: utf-8

# In[114]:


import pandas as pd
import numpy as np


# In[115]:


dataset = pd.read_csv('labeled_data.csv')


# In[116]:


dataset


# In[117]:


dataset.isnull().sum()


# In[118]:


dataset.describe()


# In[119]:


dataset["labels"]=dataset["class"].map({0: "Hate Speech",1:"Offensive language",2:"No hate or offensive language"})


# In[120]:


dataset


# In[121]:


data=dataset[["tweet","labels"]]


# In[122]:


data


# In[123]:


import re
import nltk
import string


# In[124]:


import nltk
nltk.download('stopwords')


# In[125]:


#Importing  stop words 
from nltk.corpus import stopwords
stopwords = set(stopwords.words("english"))


# In[126]:


# Importing stemming
stemmer=nltk.SnowballStemmer("english")


# In[127]:


#data cleaning
def clean_data(text):
  text=str(text).lower()
  text=re.sub('https?://\S+|www\.S+',' ',text)
  text= re.sub('\[.*?\]','',text)
  text= re.sub('<.*?>+','',text)
  text=re.sub('[%s]'%re.escape(string.punctuation),'',text)
  text=re.sub('\n','',text)
  text=re.sub('\w*\d\w*','',text)
 #stop words removal
  text= [word for word in text.split(' ') if word not in stopwords]
  text=" ".join(text)
  #stemming the text
  text = [stemmer.stem(word) for word in text.split(' ')]
  text=" ".join(text)
  return text



# In[128]:


data["tweet"]=data["tweet"].apply(clean_data)


# In[129]:


data


# In[130]:


X=np.array(data["tweet"])
y=np.array(data["labels"])


# In[131]:


X


# In[132]:


y


# In[133]:


from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split


# In[134]:


cv=CountVectorizer()
X= cv.fit_transform(X)


# In[135]:


X


# In[136]:


X_train,X_test,y_train,y_test= train_test_split(X,y,
                                                  test_size=0.33,
                                                  random_state=42)


# In[137]:


X_train


# In[138]:


from sklearn.tree import DecisionTreeClassifier


# In[139]:


dt= DecisionTreeClassifier()


# In[140]:


dt.fit(X_train, y_train)


# In[141]:


y_pred=dt.predict(X_test)


# In[142]:


from sklearn.metrics import confusion_matrix
cm= confusion_matrix(y_test,y_pred)
cm


# In[143]:


import seaborn as sns
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')


# In[144]:


sns.heatmap(cm,annot= True,fmt="f",cmap="YlGnBu")


# In[145]:


from sklearn.metrics import accuracy_score
accuracy_score(y_test,y_pred)


# In[146]:


sample="Bruh im tired of niggas retweetin Miley Cyrus naked that bitch aint no types of bad"
sample= clean_data(sample)


# In[147]:


sample=cv.transform([sample_list]).toarray()


# In[148]:


dt.predict(sample)


# In[ ]:




